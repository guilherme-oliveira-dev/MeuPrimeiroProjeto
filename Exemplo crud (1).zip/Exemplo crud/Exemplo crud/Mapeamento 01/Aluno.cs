﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo_crud.Mapeamento_01
{
    internal class Aluno
    {
        public int id_aluno;
        public string cpf;
        public string nome;
        public string sexo;
        public string telefone;
        public DateTime dataNascimento;
        public double altura;
    }
}
