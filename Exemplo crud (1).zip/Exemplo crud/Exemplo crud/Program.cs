﻿using Exemplo_crud.DAO;
using Exemplo_crud.Mapeamento_01;
using Exemplo_crud.Utilitarios;

Conexao.Conectar();
Aluno a1 = new Aluno();
{
    try
    {
        a1.id_aluno = 33;
        a1.cpf = "O3906112227";
        a1.sexo = "m";
        a1.nome = "Guilherme";
        a1.altura = 1.80;
        a1.dataNascimento = new DateTime(2002, 01, 23);
        a1.telefone = "69993063596";

        AlunoDAO adao = new AlunoDAO();
        adao.Cadastar(a1);
        Console.WriteLine("cadastrado com sucesso!");

    }
    catch (Exception ex)
    
    {
        Console.WriteLine(ex.Message);
            
    }
}