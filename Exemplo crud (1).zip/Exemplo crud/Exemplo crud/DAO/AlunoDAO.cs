﻿using Exemplo_crud.Mapeamento_01;
using Exemplo_crud.Utilitarios;
using MySql.Data.MySqlClient;
using Mysqlx.Crud;
using Org.BouncyCastle.Cms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Exemplo_crud.DAO
{
    internal class AlunoDAO
    {
        public void Cadastar(Aluno aluno)
        {
            try

            { string dataNasc = aluno.dataNascimento.ToString("yyyy-MM-dd");
                string sql = "INSERT INTO aluno (nome,cpf,dataNasc,sexo,altura,telefone)" +
                       "VALUES  (@nome,@cpf,@dataNascimento,@sexo,@altura,@telefone)";
                MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
                comando.Parameters.AddWithValue("@Nome", aluno.nome);
                comando.Parameters.AddWithValue("@cpf", aluno.cpf);
                comando.Parameters.AddWithValue("@dataNascimento", dataNasc);
                comando.Parameters.AddWithValue("@sexo", aluno.sexo);
                comando.Parameters.AddWithValue("@altura", aluno.altura);
                comando.Parameters.AddWithValue("@telefone", aluno.telefone);
                comando.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }
        }

        public void Atualizar(Aluno aluno)
        {
        string dataNasc = aluno.dataNascimento.ToString("yyyy-MM-dd");
        string sql = "UPDATE aluno SET nome= @nome,cpf = @cpf, dataNasc = @dataNasc," +
            "sexo = @sexo, altura= @altura , telefone= @telefone WHERE id_aluno = @id_aluno ";
        MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
        comando.Parameters.AddWithValue("@Nome", aluno.nome);
                comando.Parameters.AddWithValue("@cpf", aluno.cpf);
                comando.Parameters.AddWithValue("@dataNascimento", dataNasc);
                comando.Parameters.AddWithValue("@sexo", aluno.sexo);
                comando.Parameters.AddWithValue("@altura", aluno.altura);
                comando.Parameters.AddWithValue("@telefone", aluno.telefone);
                comando.ExecuteNonQuery();
                Conexao.Fecharconexao();

        

             
        }

        public void Delete(Aluno aluno)
        {
            string sql = "DELETE FROM aluno WHERE id_aluno = @id_aluno";
            MySqlCommand comando = new MySqlCommand(sql, Conexao.Conectar());
            comando.Parameters.AddWithValue("@id_aluno", aluno.id_aluno);
            comando.ExecuteNonQuery();
            Conexao.Fecharconexao();

        }

        public List<Aluno> Buscartodos()
        {
            try
            {
                string 
            }
        }
    }
}
