﻿
public class Empresario:Conta
{
    private double anuidade;
    private double limiteEmprestimo;
    private double totalEmprestimo;

}