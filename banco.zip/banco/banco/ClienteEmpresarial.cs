﻿
public class Empresario : Conta
{
    private double anuidade;
    private double limiteEmprestimo;
    private double totalEmprestimo;


    public void Fazeremprestimo(double valor)
    {
        if (valor <= limiteEmprestimo - totalEmprestimo)

        {
            totalEmprestimo += valor;
            _saldo += valor;

        }
        else
        {
            throw new Exception("valor de emprestimo não pode ser consedido");
        }


    }

    public override void Sacar(double valor)
    {
        if (valor > 5000 && valor <= _saldo - 5)
        {
            _saldo -= valor;
            _saldo = 5;
        }
        else if (valor < 5000)
        {
            base.Sacar(valor);
        }
        else

        {
            throw new Exception("Saldo insuficiente!");


        }
    } }    