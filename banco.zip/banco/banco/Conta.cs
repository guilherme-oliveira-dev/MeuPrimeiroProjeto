﻿using System.Security.Cryptography.X509Certificates;

public class Conta
{
    private int nConta;
    private string _agencia;
    private string _titular;
    protected double _saldo;
    private string valor;

    public void SetConta(int valor)
    {
        nConta = valor;
    }

    public void SetTitular(string valor)
    {
        _titular = valor;
    }

    public void SetAgencia(string valor)
    {
        _agencia = valor;

    }
    public int GetConta(string valor)
    {
        return nConta;
    }

    public string GetTitular(int valor)
    {
        return _titular;
    }

    public double GetSaldo(double saldo)
    {
        return _saldo;
    }


    public virtual void Sacar(double valor)
    {
        try
        {
            if (valor <= _saldo)
            {
                _saldo -= valor;
                Console.WriteLine("Saque efetuado com sucesso");

            }
            else
            {
                throw new Exception("Saldo Insuficiente");

            }

        }

        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }

    }

    public void Depositar(double valor)
    {
        try
        {
            if (_saldo <= 0) {
                Console.WriteLine("Não é possivel depositar valores menores que 0 ");
            }
        }

        catch (Exception ex) { "Valor invalido"};

        _saldo += valor;
        Console.WriteLine("Deposito realizado com sucesso");
    }
}



