﻿using System.Security.Cryptography.X509Certificates;

public class Conta
{
    private int nConta;
    private string _agencia;
    private string _titular;
    protected double _saldo;
    private string valor;

    public void SetConta(int valor)
    {
        nConta = valor;
    }

    public void SetTitular(string valor)
    {
        _titular = valor;
    }

    public void SetAgencia(string valor)
    {
        _agencia = valor;

    }
    public int GetConta(string valor)
    {
        return nConta;
    }

    public string GetTitular(int valor)
    {
        return _titular;
    }

    public double GetSaldo(double saldo)
    {
        return _saldo;
    }


    public virtual void Sacar(double valor)
    {
        try
        {
            if (valor <= _saldo)
            {
                _saldo -= valor;
                

            }
            else
            {
                throw new Exception("Saldo Insuficiente");

            }

        }

        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }

    }

    public void Depositar(double valor)
    {
        
        
        if (_saldo <= 0)
        {
          throw new Exception("Valor invalido");

        }
        


        _saldo += valor;
    }
}



