﻿

public class Estudante:Conta
{
    private double chequeespecial;
    private string cpf;
    private string nomedainstituicao;
}

